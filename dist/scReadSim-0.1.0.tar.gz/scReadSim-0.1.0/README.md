# scReadSim

A module for single cell sequencing read simulator.